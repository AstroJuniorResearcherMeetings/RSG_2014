Important documents and results. Where the main paper gets written
